﻿using Microsoft.AspNetCore.Mvc;

namespace AuthService.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
